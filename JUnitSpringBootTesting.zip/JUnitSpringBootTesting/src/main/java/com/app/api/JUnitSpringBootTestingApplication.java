package com.app.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JUnitSpringBootTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JUnitSpringBootTestingApplication.class, args);
	}

}
